import streamlit as st
from datetime import datetime

# Initialize session state for users and doctors if not already done
if "users" not in st.session_state:
    st.session_state.users = {"user1": {"password": "pass1", "name": "John Doe"}}
if "doctors" not in st.session_state:
    st.session_state.doctors = {"dr1": {"name": "Dr. Smith", "specialty": "General Practitioner"}}
if "page" not in st.session_state:
    st.session_state.page = "Login"  # Default page to show at start

# Function to authenticate user
def authenticate(username, password):
    if username in st.session_state.users and st.session_state.users[username]["password"] == password:
        return st.session_state.users[username]
    else:
        return None

# Main app layout
def main():
    st.title("Telemedicine Virtual Assistance")

    # Sidebar for navigation
    if 'user' in st.session_state:
        st.sidebar.write(f"Welcome, {st.session_state.user['name']}!")  # Display the username on the sidebar
        page_options = ("Dashboard", "Book Appointment", "Enter Symptoms", "Video Call")
    else:
        page_options = ("Login", "Register")
        
    page = st.sidebar.selectbox("Select a page", page_options, index=page_options.index(st.session_state.page))
    st.session_state.page = page  # Keep track of current page in session state

    # Display page based on selection
    if page == "Login":
        login_page()
    elif page == "Register":
        register_page()
    elif page == "Dashboard":
        dashboard()
    elif page == "Book Appointment":
        book_appointment()
    elif page == "Enter Symptoms":
        enter_symptoms()
    elif page == "Video Call":
        video_call()

# Dashboard Page (Home page after login/registration)
def dashboard():
    st.subheader("Dashboard")
    st.write(f"Welcome to your dashboard, {st.session_state.user['name']}!")
    st.write("Here you can manage appointments, check messages from doctors, and more.")
    
    # Display buttons for all options
    if st.button("Book Appointment"):
        st.session_state.page = "Book Appointment"
    if st.button("Enter Symptoms"):
        st.session_state.page = "Enter Symptoms"
    if st.button("Video Call"):
        st.session_state.page = "Video Call"

# Login Page
def login_page():
    st.subheader("Login")
    username = st.text_input("Username")
    password = st.text_input("Password", type="password")
    
    if st.button("Login"):
        user = authenticate(username, password)
        if user:
            st.session_state.user = user
            st.session_state.username = username
            st.success(f"Welcome {user['name']}")
            st.session_state.page = "Dashboard"  # Redirect to dashboard after login
        else:
            st.error("Invalid credentials")

# Register Page (for new users)
def register_page():
    st.subheader("Register")
    username = st.text_input("Username")
    password = st.text_input("Password", type="password")
    name = st.text_input("Full Name")
    
    if st.button("Register"):
        if username not in st.session_state.users:
            st.session_state.users[username] = {"password": password, "name": name}
            st.session_state.user = st.session_state.users[username]
            st.success("User registered successfully")
            st.session_state.page = "Dashboard"  # Redirect to dashboard after registration
        else:
            st.error("Username already exists")

# Book Appointment Page
def book_appointment():
    st.subheader("Book an Appointment")
    if 'user' not in st.session_state:
        st.warning("Please login first")
        return
    
    doctor = st.selectbox("Select a Doctor", [doctor['name'] for doctor in st.session_state.doctors.values()])
    date = st.date_input("Choose a Date", min_value=datetime.today())
    time = st.time_input("Choose a Time")
    
    if st.button("Book Appointment"):
        st.success(f"Appointment booked with {doctor} on {date} at {time}")

# Enter Symptoms Page
def enter_symptoms():
    st.subheader("Enter Symptoms")
    if 'user' not in st.session_state:
        st.warning("Please login first")
        return
    
    symptoms = st.text_area("Describe your symptoms")
    
    if st.button("Submit Symptoms"):
        st.success("Symptoms submitted. A doctor will review them shortly.")

# Video Call Page (Placeholder for integration)
def video_call():
    st.subheader("Video Call with Doctor")
    if 'user' not in st.session_state:
        st.warning("Please login first")
        return
    
    st.write("This is a placeholder for video calls.")
    st.write("You can integrate APIs like Twilio for actual video calling.")

if __name__ == "__main__":
    main()
